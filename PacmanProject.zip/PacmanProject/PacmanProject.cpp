#include "Klasy.h"

//wzorzec funkcji sprawdzaj�cej czy dochodzi do kolizji mi�dzy obiektami
template <class T1, class T2>
bool collision(T1& A, T2& B) // ZMIENI� NAZW�
{
    if ((A.right() >= B.left() && A.left() <= B.right()
        && A.bottom() >= B.top() && A.top() <= B.bottom()))
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
    //tworzymy tablice, ktora przechowuje bloczki, ktore skladaja sie na labirynt
    Block tableBlocks[blocksAmount] = {
    Block(0, 0, 650.0f, 10.0f),
    Block(0, 610, 650.0f, 10.0f),
    Block(650, 0, 10.0f, 620.0f),
    Block(0, 10, 10.0f, 600.0f),

    Block(35, 35, 60.0f, 40.0f),
    Block(35, 100, 60.0f, 15.0f),
    Block(120, 35, 80.0f, 40.0f),
    Block(225, 10, 20.0f, 65.0f),
    Block(270, 35, 80.0f, 40.0f),
    Block(375, 35, 60.0f, 40.0f),
    Block(460, 10, 20.0f, 65.0f),
    Block(505, 35, 80.0f, 40.0f),
    Block(610, 35, 15.0f, 40.0f),
    Block(35, 140, 60.0f, 20.0f),
    Block(120, 100, 20.0f, 100.0f),
    Block(140, 140, 60.0f, 20.0f),
    Block(165, 100, 140.0f, 15.0f),
    Block(35, 185, 60.0f, 15.0f),
    Block(10, 225, 85.0f, 10.0f),
    Block(10, 285, 85.0f, 10.0f),
    Block(85, 235, 10.0f, 50.0f),
    Block(10, 320, 85.0f, 10.0f),
    Block(10, 380, 85.0f, 10.0f),
    Block(85, 330, 10.0f, 50.0f),
    Block(35, 415, 60.0f, 20.0f),
    Block(10, 460, 40.0f, 10.0f),
    Block(75, 435, 20.0f, 35.0f),
    Block(35, 495, 165.0f, 20.0f),
    Block(35, 540, 60.0f, 45.0f),
    Block(120, 225, 20.0f, 70.0f),
    Block(120, 320, 20.0f, 70.0f),
    Block(120, 415, 60.0f, 20.0f),
    Block(120, 460, 20.0f, 35.0f),
    Block(225, 115, 20.0f, 45.0f),
    Block(330, 100, 20.0f, 100.0f),
    Block(270, 140, 60.0f, 20.0f),
    Block(565, 225, 85.0f, 10.0f),
    Block(565, 285, 85.0f, 10.0f),
    Block(565, 320, 85.0f, 10.0f),
    Block(565, 380, 85.0f, 10.0f),
    Block(565, 235, 10.0f, 50.0f),
    Block(565, 330, 10.0f, 50.0f),
    Block(120, 540, 80.0f, 45.0f),
    Block(225, 540, 45.0f, 45.0f),
    Block(295, 540, 140.0f, 45.0f),
    Block(460, 540, 60.0f, 45.0f),
    Block(520, 540, 50.0f, 45.0f),
    Block(595, 540, 30.0f, 45.0f),
    Block(460, 495, 165.0f, 20.0f),
    Block(610, 460, 40.0f, 10.0f),
    Block(565, 415, 60.0f, 20.0f),
    Block(565, 435, 20.0f, 35.0f),
    Block(470, 415, 70.0f, 20.0f),
    Block(520, 460, 20.0f, 35.0f),
    Block(165, 460, 130.0f, 10.0f),
    Block(225, 470, 20.0f, 45.0f),
    Block(270, 495, 165.0f, 20.0f),
    Block(320, 460, 20.0f, 35.0f),
    Block(365, 460, 130.0f, 10.0f),
    Block(610, 100, 15.0f, 30.0f),
    Block(375, 100, 170.0f, 15.0f),
    Block(375, 140, 15.0f, 60.0f),
    Block(390, 160, 70.0f, 15.0f),
    Block(415, 115, 15.0f, 20.0f),
    Block(570, 100, 15.0f, 100.0f),
    Block(610, 155, 15.0f, 45.0f),
    Block(520, 225, 20.0f, 70.0f),
    Block(520, 320, 20.0f, 70.0f),
    Block(165, 185, 140.0f, 15.0f),
    Block(165, 225, 15.0f, 70.0f),
    Block(290, 225, 15.0f, 70.0f),
    Block(205, 225, 60.0f, 70.0f),
    Block(290, 320, 105.0f, 10.0f),
    Block(290, 360, 105.0f, 10.0f),
    Block(290, 330, 10.0f, 40.0f),
    Block(385, 330, 10.0f, 40.0f),
    Block(165, 320, 15.0f, 70.0f),
    Block(205, 320, 60.0f, 20.0f),
    Block(205, 365, 60.0f, 25.0f),
    Block(205, 415, 60.0f, 20.0f),
    Block(290, 395, 105.0f, 40.0f),
    Block(420, 320, 25.0f, 115.0f),
    Block(470, 320, 25.0f, 70.0f),
    Block(330, 275, 115.0f, 20.0f),
    Block(330, 225, 20.0f, 50.0f),
    Block(470, 225, 25.0f, 70.0f),
    Block(375, 225, 70.0f, 25.0f),
    Block(205, 320, 60.0f, 20.0f)
    };
    Point tablePoints[29 * 37] = {};

    bool collisionPacmanApple = false;
    bool collisionPacmanOrange = false;
    bool collisionPacmanBanana = false;
    bool collisionPacmanCherry = false;
    bool collisionPacmanMushroom = false;

    int pointIndex = 0;
    //petla, ktora dodaje do tablicy punkty
    for (int i = 22; i < 650; i += 22)
    {
        for (int j = 22; j < 600; j += 16)
        {
            tablePoints[pointIndex++].shape.setPosition(i, j);
        }
    }

    bool collisionPackmanBlock;

    // ponizsze odpowiadaja za mierzenie czasu
    Clock clockElapsed;
    Clock clockGhost;
    Clock clockFruit;
    Time periodGhost = seconds(0);
    Time periodFruit = seconds(0);
    Time elapsed;

    srand(time(NULL));

    //zmienne potrzebne dla menu
    bool backToMenu = false;
    bool backToSubmenu = false;

    // Ustawienie domy�lnego okna z tytu�em Pacman o podanej rozdzielczo�ci
    RenderWindow window{ VideoMode{windowWith, windowHeight}, "Pacman" };
    // utworzenie obiekt�w


    Image logo;
    if (!logo.loadFromFile("images/pacman.png"))
    {

    }

    window.setIcon(logo.getSize().x, logo.getSize().y, logo.getPixelsPtr());

    SoundPlayer soundPoint("sounds/point.wav");
    SoundPlayer soundFruit("sounds/fruit.wav");
    SoundPlayer soundEnd("sounds/end.wav");
    Menu menu(window.getSize().x, window.getSize().y);
    SubMenu subMenu(window.getSize().x, window.getSize().y);
    Information instruction(window.getSize().x, window.getSize().y);
    Information aboutUs(window.getSize().x, window.getSize().y);

    Panel panelPoints(680, 50);
    Panel panelTimeElapsed(680, 140);
    Panel panelLifeAmount(680, 230);
    Panel panelPower(680, 320);
    Panel panelLevel(680, 410);
    Panel panelRecord(680, 500);
    Pacman pacmanLife[3] =
    {
        Pacman(690, 270),
        Pacman(715, 270),
        Pacman(740, 270)
    };
    Apple applePanel(680, 350);
    Orange orangePanel(702, 350);
    Banana bananaPanel(724, 350);
    Cherry cherryPanel(746, 350);
    Mushroom mushroomPanel(768, 350);

    GameOver gameOverTitle(250, 50);
    GameOver gameOverPoints(250, 180);
    GameOver gameOverTime(250, 300);
    GameOver gameOverRecord(250, 420);

    // aby gameloop dzia�a� 60 razy na sekunde
    window.setFramerateLimit(60);
    // dowolne wydarzenie interakcji z u�ytkownikiem
    Event event;
    //zmienne potrzebne dla poruszania sie duszka
    int directionGhost1 = 1;
    int directionGhost2 = 1;
    int directionGhost3 = 1;
    int directionGhost4 = 1;
    int pointsAmount = 0;
    // liczba zyc
    int life = 3;
    //g�owna p�tla
    while (true)
    {
        while (window.pollEvent(event))
        {
            // utworzenie obiektow 
            Pacman pacman(325, 308);
            Ghost ghost1(25, 20, "red");
            Ghost ghost2(25, 595, "green");
            Ghost ghost3(640, 20, "magenta");
            Ghost ghost4(640, 595, "cyan");

            Apple apple(100, 60);
            Orange orange(13, 92);
            Banana banana(58, 77);
            Cherry cherry(158, 77);
            Mushroom mushroom(178, 77);
            switch (event.type)
            {
            case Event::KeyReleased:
                // poruszanie si� u�ytkownika w menu startowym
                switch (event.key.code)
                {
                case Keyboard::Up:
                    menu.moveUp(menu.menu, menu.color);
                    break;
                case Keyboard::Down:
                    menu.moveDown(menu.menu, menu.color);
                    break;
                case Keyboard::Return:
                    // w zale�no�ci od tego czy wybierzemy play, options lub exit to wykonaj� si� odpowienie czynno�ci
                    switch (menu.getPressedItem())
                    {
                    case 0:
                        std::cout << "Play button" << endl;


                        for (int i = 0; i < 29 * 37; i++)
                        {
                            tablePoints[i].shape.setFillColor(Color::White);

                            for (int j = 0; j < blocksAmount; j++)
                            {
                                // w przypadku gdy dochodzi do kolizji punktu z labiryntem to zmieniamy kolor punktu na przezroczysty
                                if (collision(tablePoints[i], tableBlocks[j]) == true)
                                {
                                    tablePoints[i].changeColor();
                                }
                            }
                        }

                        //(zeby owoce pokazywaly sie od nowa)
                        clockElapsed.restart();
                        periodFruit = seconds(0);

                        pointsAmount = 0;
                        life = 3;

                        for (int i = 0; i < 3; i++)
                        {
                            pacmanLife[i].pacman.setColor(Color::White);
                        }

                        while (backToMenu != true)
                        {
                            collisionPackmanBlock = false;

                            applePanel.fruit.setColor(Color(255, 255, 255, 100));
                            orangePanel.fruit.setColor(Color(255, 255, 255, 100));
                            bananaPanel.fruit.setColor(Color(255, 255, 255, 100));
                            cherryPanel.fruit.setColor(Color(255, 255, 255, 100));
                            mushroomPanel.fruit.setColor(Color(255, 255, 255, 100));

                            window.clear(Color::Black);
                            if (event.type == Event::Closed)
                            {
                                window.close();
                                break;
                            }
                            // je�li dosz�o do kolizji pacmana z kt�rym� duszkiem
                            if (collision(pacman, ghost1) == true || collision(pacman, ghost2) == true
                                || collision(pacman, ghost3) == true || collision(pacman, ghost4) == true)
                            {
                                soundEnd.play();
                                pacman.pacman.setPosition(325, 308);
                                pacman.pacman.setRotation(0);
                                ghost1.ghost.setPosition(25, 20);
                                ghost2.ghost.setPosition(25, 595);
                                ghost3.ghost.setPosition(640, 20);
                                ghost4.ghost.setPosition(640, 595);
                                life--;
                                pacmanLife[life].pacman.setColor(Color(255, 255, 255, 100));
                                cout << life;
                                if (life == 0)
                                {
                                    while (backToMenu != true)
                                    {
                                        while (window.pollEvent(event))
                                        {
                                            switch (event.type)
                                            {
                                            case Event::KeyReleased:
                                                switch (event.key.code)
                                                {
                                                case Keyboard::Enter:
                                                    backToMenu = true;
                                                    break;
                                                }
                                                break;
                                            case Event::Closed:
                                                window.close();
                                                break;
                                            }
                                        }

                                        window.clear(Color::Black);

                                        gameOverTitle.showingTitle(window, gameOverTitle.text);
                                        gameOverPoints.showingPoints(window, gameOverPoints.text, pointsAmount);
                                        gameOverTime.showingTime(window, gameOverTime.text, elapsed);
                                        gameOverRecord.showingRecord(window, gameOverRecord.text, pointsAmount);

                                        window.display();
                                    }
                                }
                            }

                            //sprawdzanie czy nie dojdzie do kolziji pacmana z bloczkiem w zaleznosci od ruchu uzytkownika
                            for (int i = 0; i < blocksAmount; i++)
                            {
                                if (Keyboard::isKeyPressed(Keyboard::Key::Right))
                                {
                                    if ((pacman.right() + 5) >= tableBlocks[i].left() && (pacman.left() + 5) <= tableBlocks[i].right()
                                        && pacman.bottom() >= tableBlocks[i].top() && pacman.top() <= tableBlocks[i].bottom())
                                    {
                                        collisionPackmanBlock = true;
                                        break;
                                    }

                                }
                                else if (Keyboard::isKeyPressed(Keyboard::Key::Left))
                                {
                                    if ((pacman.right() - 5) >= tableBlocks[i].left() && pacman.left() - 5 <= tableBlocks[i].right()
                                        && pacman.bottom() >= tableBlocks[i].top() && pacman.top() <= tableBlocks[i].bottom())
                                    {
                                        collisionPackmanBlock = true;
                                        break;
                                    }

                                }
                                else if (Keyboard::isKeyPressed(Keyboard::Key::Up))
                                {
                                    if ((pacman.right()) >= tableBlocks[i].left() && pacman.left() <= tableBlocks[i].right()
                                        && pacman.bottom() - 5 >= tableBlocks[i].top() && pacman.top() - 5 <= tableBlocks[i].bottom())
                                    {
                                        collisionPackmanBlock = true;
                                        break;
                                    }

                                }
                                else if (Keyboard::isKeyPressed(Keyboard::Key::Down))
                                {
                                    if ((pacman.right()) >= tableBlocks[i].left() && pacman.left() <= tableBlocks[i].right()
                                        && pacman.bottom() + 5 >= tableBlocks[i].top() && pacman.top() + 5 <= tableBlocks[i].bottom())
                                    {
                                        collisionPackmanBlock = true;
                                        break;
                                    }

                                }
                            }
                            periodFruit += clockFruit.restart();

                            if (apple.fruit.getColor() != Color::Transparent && collision(pacman, apple) == true)
                            {

                                collisionPacmanApple = true;
                                soundFruit.play();
                                pointsAmount = pointsAmount + 25;
                                applePanel.fruit.setColor(Color::White);
                            }

                            if (orange.fruit.getColor() != Color::Transparent && collision(pacman, orange) == true)
                            {
                                collisionPacmanOrange = true;
                                soundFruit.play();
                            }

                            if (banana.fruit.getColor() != Color::Transparent && collision(pacman, banana) == true)
                            {
                                collisionPacmanBanana = true;
                                soundFruit.play();
                            }

                            if (cherry.fruit.getColor() != Color::Transparent && collision(pacman, cherry) == true)
                            {
                                collisionPacmanCherry = true;
                                soundFruit.play();
                            }
                            if (mushroom.fruit.getColor() != Color::Transparent && collision(pacman, mushroom) == true)
                            {
                                collisionPacmanMushroom = true;
                                soundFruit.play();
                            }

                            //aktualizowanie stanu gry
                            if (collisionPackmanBlock == false)
                            {
                                pacman.update(collisionPacmanMushroom, periodFruit);
                            }

                            periodGhost += clockGhost.restart();

                            // zmienianie ruchu duszkow co sekunde
                            if (periodGhost >= seconds(1))
                            {
                                directionGhost1 = ghost1.whichDirection();
                                directionGhost2 = ghost2.whichDirection();
                                directionGhost3 = ghost3.whichDirection();
                                directionGhost4 = ghost4.whichDirection();

                                periodGhost = seconds(0);
                            }
                            for (int i = 0; i < blocksAmount; i++)
                            {
                                directionGhost1 = collisionGhostBlock(ghost1, tableBlocks[i], directionGhost1);
                                directionGhost2 = collisionGhostBlock(ghost2, tableBlocks[i], directionGhost2);
                                directionGhost3 = collisionGhostBlock(ghost3, tableBlocks[i], directionGhost3);
                                directionGhost4 = collisionGhostBlock(ghost4, tableBlocks[i], directionGhost4);
                            }

                            ghost1.updateChange(directionGhost1, periodFruit, collisionPacmanCherry);
                            ghost2.updateChange(directionGhost2, periodFruit, collisionPacmanCherry);
                            ghost3.updateChange(directionGhost3, periodFruit, collisionPacmanCherry);
                            ghost4.updateChange(directionGhost4, periodFruit, collisionPacmanCherry);




                            setFruit(periodFruit, collisionPacmanApple, collisionPacmanOrange, collisionPacmanBanana, collisionPacmanCherry, collisionPacmanMushroom, apple, orange, banana, cherry, mushroom);

                            for (int i = 0; i < blocksAmount; i++)
                            {
                                window.draw(tableBlocks[i]);
                            }

                            if (collisionPacmanOrange == true)
                            {
                                orangePanel.fruit.setColor(Color::White);

                                for (int i = 0; i < blocksAmount; i++)
                                {
                                    if (Keyboard::isKeyPressed(Keyboard::Key::Right))
                                    {
                                        if ((pacman.right() + 10) >= tableBlocks[i].left() && (pacman.left() + 10) <= tableBlocks[i].right()
                                            && pacman.bottom() >= tableBlocks[i].top() && pacman.top() <= tableBlocks[i].bottom())
                                        {
                                            collisionPackmanBlock = true;
                                            break;
                                        }

                                    }
                                    else if (Keyboard::isKeyPressed(Keyboard::Key::Left))
                                    {
                                        if ((pacman.right() - 10) >= tableBlocks[i].left() && pacman.left() - 10 <= tableBlocks[i].right()
                                            && pacman.bottom() >= tableBlocks[i].top() && pacman.top() <= tableBlocks[i].bottom())
                                        {
                                            collisionPackmanBlock = true;
                                            break;
                                        }

                                    }
                                    else if (Keyboard::isKeyPressed(Keyboard::Key::Up))
                                    {
                                        if ((pacman.right()) >= tableBlocks[i].left() && pacman.left() <= tableBlocks[i].right()
                                            && pacman.bottom() - 10 >= tableBlocks[i].top() && pacman.top() - 10 <= tableBlocks[i].bottom())
                                        {
                                            collisionPackmanBlock = true;
                                            break;
                                        }

                                    }
                                    else if (Keyboard::isKeyPressed(Keyboard::Key::Down))
                                    {
                                        if ((pacman.right()) >= tableBlocks[i].left() && pacman.left() <= tableBlocks[i].right()
                                            && pacman.bottom() + 10 >= tableBlocks[i].top() && pacman.top() + 10 <= tableBlocks[i].bottom())
                                        {
                                            collisionPackmanBlock = true;
                                            break;
                                        }

                                    }
                                }
                                if (collisionPackmanBlock == false && periodFruit >= seconds(10)
                                    && periodFruit <= seconds(16))
                                {
                                    pacman.update(collisionPacmanMushroom, periodFruit);
                                }
                            }

                            for (int i = 0; i < 29 * 37; i++)
                            {
                                if (collisionPacmanBanana == false)
                                {
                                    if (collision(tablePoints[i], pacman) == true &&
                                        tablePoints[i].shape.getFillColor() != Color::Transparent)
                                    {
                                        soundPoint.play();
                                        pointsAmount++;
                                        tablePoints[i].changeColor();
                                    }
                                }
                                else
                                {

                                    bananaPanel.fruit.setColor(Color::White);
                                    if (collision(tablePoints[i], pacman) == true &&
                                        tablePoints[i].shape.getFillColor() != Color::Transparent && periodFruit >= seconds(15)
                                        && periodFruit <= seconds(21))
                                    {
                                        soundPoint.play();
                                        pointsAmount = pointsAmount + 2;
                                        tablePoints[i].changeColor();
                                    }
                                }
                                window.draw(tablePoints[i]);

                            }

                            //rysowanie obiekt�w
                            window.draw(pacman);
                            window.draw(ghost1);
                            window.draw(ghost2);
                            window.draw(ghost3);
                            window.draw(ghost4);

                            window.draw(apple);
                            window.draw(orange);
                            window.draw(banana);
                            window.draw(cherry);
                            window.draw(mushroom);

                            panelPoints.showingPoints(window, panelPoints.text, pointsAmount);
                            elapsed = clockElapsed.getElapsedTime();
                            panelTimeElapsed.showingTime(window, panelTimeElapsed.text, elapsed);
                            panelLifeAmount.showingLife(window, panelLifeAmount.text);
                            for (int i = 0; i < 3; i++)
                            {
                                window.draw(pacmanLife[i]);
                            }
                            panelPower.showingPower(window, panelPower.text);
                            window.draw(applePanel);
                            window.draw(orangePanel);
                            window.draw(bananaPanel);
                            window.draw(cherryPanel);
                            window.draw(mushroomPanel);
                            panelLevel.showingLevel(window, panelLevel.text, 1);
                            panelRecord.showingRecord(window, panelRecord.text, pointsAmount);

                            window.display();
                        }
                        backToMenu = false;
                        break;
                    case 1:
                        std::cout << "Option button" << endl;
                        while (backToMenu != true)
                        {
                            while (window.pollEvent(event))
                            {
                                //window.clear(Color::Black);
                                switch (event.type)
                                {
                                case Event::KeyReleased:
                                    // poruszanie si� u�ytkownika w podmenu
                                    switch (event.key.code)
                                    {
                                    case Keyboard::Escape:
                                        backToMenu = true;
                                        break;
                                    case Keyboard::Up:
                                        subMenu.moveUp(subMenu.subMenu, subMenu.color);
                                        break;
                                    case Keyboard::Down:
                                        subMenu.moveDown(subMenu.subMenu, subMenu.color);
                                        break;
                                    case Keyboard::Return:
                                        // w zale�no�ci od tego czy wybierzemy play, options lub exit to wykonaj� si� odpowienie czynno�ci
                                        switch (subMenu.getPressedItem())
                                        {
                                        case 0:
                                            std::cout << "instrukcje hyhy" << endl;
                                            while (backToSubmenu != true)
                                            {
                                                while (window.pollEvent(event))
                                                {
                                                    switch (event.type)
                                                    {
                                                    case Event::KeyReleased:
                                                        switch (event.key.code)
                                                        {
                                                        case Keyboard::Escape:
                                                            backToSubmenu = true;
                                                            break;
                                                        }
                                                        break;
                                                    case Event::Closed:
                                                        window.close();
                                                        break;
                                                    }
                                                }

                                                window.clear(Color::Black);

                                                instruction.informationShowing(window, instruction.text, "txt/instruction.txt");
                                                window.display();
                                            }
                                            backToSubmenu = false;
                                            break;
                                        case 1:
                                            cout << "o nas hyhy" << endl;
                                            while (backToSubmenu != true)
                                            {
                                                while (window.pollEvent(event))
                                                {
                                                    switch (event.type)
                                                    {
                                                    case Event::KeyReleased:
                                                        switch (event.key.code)
                                                        {
                                                        case Keyboard::Escape:
                                                            backToSubmenu = true;
                                                            break;
                                                        }
                                                        break;
                                                    case Event::Closed:
                                                        window.close();
                                                        break;
                                                    }
                                                }

                                                window.clear(Color::Black);

                                                aboutUs.informationShowing(window, instruction.text, "txt/aboutUs.txt");
                                                window.display();
                                            }
                                            backToSubmenu = false;
                                            break;
                                        case 2:
                                            std::cout << "wroc do menu" << endl;
                                            backToMenu = true;
                                            break;
                                        }
                                        break;
                                    }
                                    break;
                                case Event::Closed:
                                    window.close();
                                    break;
                                }
                            }

                            window.clear(Color::Black);

                            subMenu.draw(window, subMenu.subMenu);
                            window.display();
                        }
                        backToMenu = false;
                        break;
                    case 2:
                        window.close();
                        break;
                    }
                    break;
                }
                break;
            case Event::Closed:
                window.close();
                break;
            }
        }
        window.clear(Color::Black);

        menu.draw(window, menu.menu);
        window.display();
    }
}
